## Here be dragons

### Disclaimer

The code in this directory is only for experimental purposes. It could be unreliable or unstable, could be not well tested or could fail. There is no guarantee about the future of the code here, whether it could be removed or utterly changed. It exists here for the beta testing purposes or discussions. Should something from here be used in the non-experimental code it will be moved outside of experimental directory.
