# Code of Conduct

osquery has adopted a Code of Conduct that we expect project participants to adhere to. Please [read the full text](https://github.com/osquery/foundation/blob/main/CODE_OF_CONDUCT.md) so that you can understand what actions will and will not be tolerated.
