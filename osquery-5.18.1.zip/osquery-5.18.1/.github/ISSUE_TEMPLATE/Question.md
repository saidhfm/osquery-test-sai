---
name: Question
about: You have a question about osquery
title: ''
labels: ''
assignees: ''

---

<!-- Thank you for your interest in osquery! -->

# Question

**We are happy to help, however please DO NOT submit issues for questions about osquery.**

We only use issues to track bugs, feature requests or blueprints. For everything else, check out Slack or the other channels below:

Slack : https://osquery.slack.com

Slack newcomers, first use this invite link: https://join.slack.com/t/osquery/shared_invite/zt-1wipcuc04-DBXmo51zYJKBu3_EP3xZPA

Reddit : https://www.reddit.com/r/osquery/

Stack Overflow : https://stackoverflow.com/tags/osquery


**If you go ahead and submit an issue with a question it will not be answered.**
