---
name: Task
about: A generic task or TODO item
title: ''
labels: ''
assignees: ''

---

<!-- Thank you for contributing to osquery! -->

# Task

<!--
Before you submit, are you sure there isn't a better template for you?
This is mostly used by the core maintainer team to keep track of tasks.
-->
