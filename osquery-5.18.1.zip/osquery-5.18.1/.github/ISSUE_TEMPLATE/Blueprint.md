---
name: Blueprint
about: You're planning on implementing a change
title: ''
labels: ''
assignees: ''

---

<!-- Thank you for contributing to osquery! -->

# Blueprint

<!--
There isn't a format for Blueprints so follow what makes sense for you.
-->
