@mainpage osquery api documentation

This is the generated public api documentation for osquery. For more free-form
documentation, see the GitHub wiki: https://github.com/osquery/osquery/wiki.
